<?php
/**
 * Empty Template for Old version customization users.
 * 
 * @since 6.5.1
 */